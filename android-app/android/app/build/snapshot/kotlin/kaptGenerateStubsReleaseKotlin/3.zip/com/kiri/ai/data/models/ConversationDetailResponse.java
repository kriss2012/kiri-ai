package com.kiri.ai.data.models;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001d\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\u0010\u0010\f\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003\u00a2\u0006\u0002\u0010\nJ\u000b\u0010\r\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J&\u0010\u000e\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u00c6\u0001\u00a2\u0006\u0002\u0010\u000fJ\u0013\u0010\u0010\u001a\u00020\u00032\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0012\u001a\u00020\u0013H\u00d6\u0001J\t\u0010\u0014\u001a\u00020\u0015H\u00d6\u0001R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0015\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\n\n\u0002\u0010\u000b\u001a\u0004\b\t\u0010\n\u00a8\u0006\u0016"}, d2 = {"Lcom/kiri/ai/data/models/ConversationDetailResponse;", "", "success", "", "conversation", "Lcom/kiri/ai/data/models/ChatDetail;", "(Ljava/lang/Boolean;Lcom/kiri/ai/data/models/ChatDetail;)V", "getConversation", "()Lcom/kiri/ai/data/models/ChatDetail;", "getSuccess", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "component1", "component2", "copy", "(Ljava/lang/Boolean;Lcom/kiri/ai/data/models/ChatDetail;)Lcom/kiri/ai/data/models/ConversationDetailResponse;", "equals", "other", "hashCode", "", "toString", "", "app_release"})
public final class ConversationDetailResponse {
    @org.jetbrains.annotations.Nullable()
    private final java.lang.Boolean success = null;
    @org.jetbrains.annotations.Nullable()
    private final com.kiri.ai.data.models.ChatDetail conversation = null;
    
    public ConversationDetailResponse(@org.jetbrains.annotations.Nullable()
    java.lang.Boolean success, @org.jetbrains.annotations.Nullable()
    com.kiri.ai.data.models.ChatDetail conversation) {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Boolean getSuccess() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.kiri.ai.data.models.ChatDetail getConversation() {
        return null;
    }
    
    public ConversationDetailResponse() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Boolean component1() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.kiri.ai.data.models.ChatDetail component2() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.kiri.ai.data.models.ConversationDetailResponse copy(@org.jetbrains.annotations.Nullable()
    java.lang.Boolean success, @org.jetbrains.annotations.Nullable()
    com.kiri.ai.data.models.ChatDetail conversation) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}